import sys
from PyQt6.QtCore import Qt
import PyQt6.QtWidgets as qtw
from PyQt6.QtWidgets import QApplication, QWidget
from qt_material import apply_stylesheet
from PyQt6.QtGui import QFont,QIntValidator
import random as rand


class MainWindow(QWidget):
    
    def __init__(self):
        super().__init__()
        self.att=0
        self.to_get=self.generator()
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, False)
        
        self.setWindowTitle("Guess The Number")
        self.setLayout(qtw.QVBoxLayout())
        self.keypad()

    def keypad(self):

        container = qtw.QWidget(self)
        container.setLayout(qtw.QGridLayout())

        self.input_text = qtw.QLineEdit()
        self.input_text.setPlaceholderText("Enter The Number")

        int_validator = QIntValidator()
        self.input_text.setValidator(int_validator)

        self.input_text.returnPressed.connect(self.check_input)
        self.input_text.setFont(QFont("Arial", 12))
        placeholder_style = "color: cyan;"
        self.input_text.setStyleSheet(placeholder_style)

        self.btn_result=qtw.QPushButton("The Result will be shown here",self)
        self.btn_reset= qtw.QPushButton("Change guessing Number",self)
        

        container.layout().addWidget(self.input_text,0,0,1,1)
        container.layout().addWidget(self.btn_result,1,0,1,1)
        container.layout().addWidget(self.btn_reset,2,0,1,1)

        common_stylesheet = """
            QPushButton {
                padding: 5px;
                background-color: #000000;
                color: #0EFF1E;
                border: 2px solid cyan;
                border-radius: 15px;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """
        self.btn_reset.setStyleSheet(common_stylesheet)
        self.btn_result.setStyleSheet(common_stylesheet)

        self.btn_reset.clicked.connect(lambda:self.reset())
        self.layout().addWidget(container)
        
    
    def generator(self):
        return rand.randint(0,100)

    def check_input(self):
        input_text=int(self.input_text.text())
        if self.to_get==input_text:
            self.att+=1
            self.btn_result.setText(f"Yes you pass this in {self.att} atempts")
        elif self.to_get<input_text:
            self.btn_result.setText(f"Try some smaller one")
            self.att+=1
        else :
            self.btn_result.setText(f"Try some bigger one")
            self.att+=1

    def reset(self):
        self.input_text.clear()
        self.input_text.setPlaceholderText("Start typing here...")
        self.btn_result.setText("The gussing number has been changed")
        self.to_get=self.generator()



if __name__ == '__main__':
    app=QApplication(sys.argv)
    window=MainWindow()
    
    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    apply_stylesheet(app,'dark_red.xml')
    
    window.show()
    sys.exit(app.exec())