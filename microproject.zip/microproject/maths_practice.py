import sys
from PyQt6.QtGui import QFont,QIntValidator
from PyQt6.QtCore import Qt
import PyQt6.QtWidgets as qtw
from qt_material import apply_stylesheet
from PyQt6.QtWidgets import QApplication, QWidget

import random as rand

class MainWindow(QWidget):
    
    def __init__(self):
        super().__init__()
        
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, False)

        self.middle=0
        self.first=0
        self.last=0
        self.right=0
        self.wrong=0
                
        self.setWindowTitle("Quiz")
        self.setLayout(qtw.QVBoxLayout())
        self.keypad()
    

    def keypad(self):
        container=qtw.QWidget()
        container.setLayout(qtw.QGridLayout())

        
        self.input_text = qtw.QLineEdit()
        self.input_text.setPlaceholderText("Write ans here...")
        int_validator = QIntValidator()
        self.input_text.setValidator(int_validator)
        self.input_text.returnPressed.connect(self.check_input)
        self.input_text.setFont(QFont("Arial", 12))
        placeholder_style = "color: cyan;"
        self.input_text.setStyleSheet(placeholder_style)
        
        self.btn_quetion=qtw.QPushButton("quetion come here",self)
        self.btn_result=qtw.QPushButton("Ans will be shown here if yours is wrong",self)
        self.btn_start=qtw.QPushButton("Start",self)
        self.btn_randw=qtw.QPushButton("right and wrong comes here",self)

        container.layout().addWidget(self.btn_quetion,0,0,1,3)
        container.layout().addWidget(self.input_text,1,0,1,3)
        container.layout().addWidget(self.btn_result,2,0,1,3)
        container.layout().addWidget(self.btn_start,3,0,1,3)
        container.layout().addWidget(self.btn_randw,4,0,1,3)

        self.btn_start.clicked.connect(lambda: self.func_start())


        self.layout().addWidget(container)

        common_stylesheet = """
            QPushButton {
                padding: 5px;
                background-color: #000000;
                color: #0EFF1E;
                border: 2px solid cyan;
                border-radius: 15px;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """
        self.btn_quetion.setStyleSheet(common_stylesheet)
        self.btn_result.setStyleSheet(common_stylesheet)
        self.btn_start.setStyleSheet(common_stylesheet)
        self.btn_randw.setStyleSheet(common_stylesheet)

    
    def generator(self):
        opre=["+","-","*","/"]
        self.middle=opre[rand.randint(0,3)]

        self.first=rand.randint(0,50)
        self.last=rand.randint(0,50)
        
        if self.middle=="-":
            if self.first - self.last <0:
                self.min()
        elif self.middle=="/":
            if self.first % self.last!=0:
                self.div()

            
    def div(self):
        self.first = rand.randint(0, 50)
        self.last = rand.randint(1, 10)  # Ensure last is not zero

        if self.first % self.last != 0 and self.first / self.last != 0:
            self.div()


    def min(self):
        self.first=rand.randint(0,50)
        self.last=rand.randint(0,50)

        if self.first - self.last<=0:
            self.min()



    def func_start(self):
        self.btn_start.setText("New Question")
        self.generator()
        self.btn_quetion.setText(f"{self.first} {self.middle} {self.last}")


    def check_input(self):
        if self.middle=="+":
            self.ans=self.first + self.last
            if self.ans==int(self.input_text.text()):
                self.btn_result.setText("Ans is right")
                self.right+=1
                self.btn_randw.setText(f"Right ans = {self.right} and wrong = {self.wrong}")
                self.func_start()

            else :
                self.btn_result.setText(f"The ans is {self.ans}")
                self.wrong+=1
                self.func_start()

        elif self.middle=="-":
            self.btn_result.setText(f"{self.first - self.last}")
            self.ans=self.first - self.last
            if self.ans==int(self.input_text.text()):
                self.btn_result.setText("Ans is right")
                self.right+=1
                self.btn_randw.setText(f"Right ans = {self.right} and wrong = {self.wrong}")
                self.func_start()

            else :
                self.btn_result.setText(f"The ans is {self.ans}")
                self.wrong+=1
                self.btn_randw.setText(f"Right ans = {self.right} and wrong = {self.wrong}")
                self.func_start()
        
        elif self.middle=="*":
            self.btn_result.setText(f"{self.first * self.last}")
            self.ans=self.first * self.last
            if self.ans==int(self.input_text.text()):
                self.btn_result.setText("Ans is right")
                self.right+=1
                self.btn_randw.setText(f"Right ans = {self.right} and wrong = {self.wrong}")
                self.func_start()

            else :
                self.btn_result.setText(f"The ans is {self.ans}")
                self.wrong+=1
                self.btn_randw.setText(f"Right ans = {self.right} and wrong = {self.wrong}")
                self.func_start()

        else:
            self.btn_result.setText(f"{int(self.first / self.last)}")
            self.ans=self.first / self.last
            if self.ans==int(self.input_text.text()):
                self.btn_result.setText("Ans is right")
                self.right+=1
                self.btn_randw.setText(f"Right ans = {self.right} and wrong = {self.wrong}")
                self.func_start()

            else :
                self.btn_result.setText(f"The ans is {self.ans}")
                self.wrong+=1
                self.btn_randw.setText(f"Right ans = {self.right} and wrong = {self.wrong}")
                self.func_start()

        
        
    


if __name__ == '__main__':
    app=QApplication(sys.argv)
    window=MainWindow()
    
    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    apply_stylesheet(app, 'dark_lightgreen.xml')

    window.show()
    sys.exit(app.exec())