import sys
from PyQt6.QtWidgets import QApplication,QWidget,QLabel,QTextEdit,QLineEdit,QPushButton,QGridLayout
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt, QDateTime, QTimer
from qt_material import apply_stylesheet
import random as rand


class Mainwindow(QWidget):
    def __init__(self):
        super().__init__()
        self.sy=0
        self.keypad()
    
    def keypad(self):
        self.text_to_type = ""
        self.start_time = None
        
        self.label_instruction = QLabel("Type the following:")
        self.label_instruction.setStyleSheet("color: cyan")
        self.text_display = QTextEdit()
        self.text_display.setPlaceholderText("Text to type will appear here")
        self.text_display.setReadOnly(True)
        self.text_display.setFont(QFont("Arial", 12))
        self.text_display.setStyleSheet("""font-size: 30px""")

        self.label_result = QLabel("Start typing...")
        self.label_result.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.validation_text = QLabel("")
        self.validation_text.setAlignment(Qt.AlignmentFlag.AlignLeft)

        self.input_text = QLineEdit()
        self.input_text.setPlaceholderText("Start typing here...")
        self.input_text.returnPressed.connect(self.check_input)
        self.input_text.setFont(QFont("Arial", 12))
        placeholder_style = "color: yellow;"
        self.input_text.setStyleSheet(placeholder_style)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)

        self.start_button = QPushButton("Start Typing Test")
        self.start_button.clicked.connect(self.start_test)
        self.start_button.setFont(QFont("Arial", 12))

        self.reset_button = QPushButton("Reset")
        self.reset_button.clicked.connect(self.reset_test)
        self.reset_button.setFont(QFont("Arial", 12))

        layout = QGridLayout()

        layout.addWidget(self.label_instruction, 0, 0, 1, 2)
        layout.addWidget(self.text_display, 1, 0, 1, 2)
        layout.addWidget(self.input_text, 2, 0, 1, 2)
        layout.addWidget(self.validation_text, 3, 0)
        layout.addWidget(self.label_result, 3, 1)
        layout.addWidget(self.start_button, 4, 0)
        layout.addWidget(self.reset_button, 4, 1)

        common_stylesheet = """
            QLabel#label_result {
                color: cyan;
                font-size: 14px;
            }
            QLabel#validation_text {
                color: cyan;
                font-size: 14px;
            }
            
            QPushButton {
                padding: 5px;
                background-color: #000000;
                color: #0EFF1E;
                border: 2px solid cyan;
                border-radius: 15px;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """

        
        self.start_button.setStyleSheet(common_stylesheet)        
        self.reset_button.setStyleSheet(common_stylesheet)        
        self.label_result.setStyleSheet(common_stylesheet)
        self.validation_text.setStyleSheet(common_stylesheet)        

        self.setLayout(layout)
        self.setWindowTitle("Typing Speed Checker")
        self.setGeometry(100, 100, 400, 300)


    def generate_random_text(self):
        words = [
            """The morning sun bathes the world in a golden glow, promising a day of endless possibilities""",
            """Under the starlit sky, a gentle breeze carries whispers of dreams, as the night unfolds its mysteries""",
            """Amidst the city's hustle, a solitary tree stands, a silent witness to the ebb and flow of time.""",
            """Lost in the melody of raindrops, the city finds solace in the soothing rhythm of a gentle storm.""",
            """Dusk whispers tales of tranquility, a quiet prelude to the night's embrace.""",
            """Moonlit whispers grace the night, as stars twinkle in the cosmic lullaby of the universe""",
            """The sun sets behind the mountains, casting a warm glow across the tranquil lake""",
            "Whispers of autumn breeze rustle the golden leaves.",
        ]
        hi=rand.randint(0,7)
        return words[hi]

    def start_test(self):
        self.text_to_type = self.generate_random_text()
        self.text_display.setPlainText(self.text_to_type)
        self.input_text.clear()
        self.validation_text.setText("Start typing...")
        self.start_time = QDateTime.currentDateTime()
        self.timer.start(1000)

    def reset_test(self):
        if self.sy==0:
            self.validation_text.setText("First start the game")
        else:
            self.start_test()

    def check_input(self):
        input_text = self.input_text.text()
        if self.start_time is not None and input_text == self.text_to_type:
            self.timer.stop()
            time_taking = self.start_time.secsTo(QDateTime.currentDateTime())
            speed = len(self.text_to_type) / (time_taking / 60)
            self.label_result.setText(f"Correct! Typing speed: {speed:.2f} words per minute")
            self.start_time = None
            self.validation_text.setText("")
        else:
            self.validation_text.setText("Incorrect typing. Keep going!")

    def update_timer(self):
        time_taking = self.start_time.secsTo(QDateTime.currentDateTime())
        self.label_result.setText(f"Elapsed time: {time_taking} seconds")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    apply_stylesheet(app,"dark_red.xml")
    typing_speed_checker = Mainwindow()
    typing_speed_checker.show()
    sys.exit(app.exec())
