import sys
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication, QWidget, QFrame, QGridLayout, QVBoxLayout, QPushButton
from qt_material import apply_stylesheet
import TTT
import typing_test_game
import Stone_papper_scissor
import guess_the_number
import quiz
import maths_practice
import keyboard


class MainWindow(QWidget):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Game Zone")
        self.setStyleSheet("background-color : #000000")
        self.setFixedSize(900, 608)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, False)

        self.mainlayout = QGridLayout()
        self.seperator = QFrame()
        self.leftlayout = QVBoxLayout()
        self.rightlayout = QVBoxLayout()

        self.seperator.setFrameShape(QFrame.Shape.VLine)
        self.seperator.setFrameShadow(QFrame.Shadow.Sunken)

        self.TICTT = QPushButton("TIC TAC TOE")
        self.TICTT.clicked.connect(self.TICTACTOE)
        self.rightlayout.addWidget(self.TICTT)

        self.SPSbtn = QPushButton("STONE PAPER SCISSORS")
        self.SPSbtn.clicked.connect(self.STONE_PAPER_SCISSORS)
        self.rightlayout.addWidget(self.SPSbtn)

        self.GTN = QPushButton("Guess the number")
        self.GTN.clicked.connect(self.GuessNumber)
        self.rightlayout.addWidget(self.GTN)

        self.Quizzz = QPushButton("Quiz")
        self.Quizzz.clicked.connect(self.QuizWidget)
        self.rightlayout.addWidget(self.Quizzz)

        self.MATHBTN = QPushButton("Math practice")
        self.MATHBTN.clicked.connect(self.MathWidget)
        self.rightlayout.addWidget(self.MATHBTN)

        self.typingbtn = QPushButton("Typing Game")
        self.typingbtn.clicked.connect(self.Typing_game)
        self.rightlayout.addWidget(self.typingbtn)

        self.keyboardbtn = QPushButton("Keyboard")
        self.keyboardbtn.clicked.connect(self.keyboard_func)
        self.rightlayout.addWidget(self.keyboardbtn)


        common_stylesheet = """
            QPushButton {
                padding: 5px;
                background-color: #000000;
                color: #0EFF1E;
                border: 2px solid cyan;
                border-radius: 15px;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """
        self.TICTT.setStyleSheet(common_stylesheet)
        self.SPSbtn.setStyleSheet(common_stylesheet)
        self.GTN.setStyleSheet(common_stylesheet)
        self.Quizzz.setStyleSheet(common_stylesheet)
        self.MATHBTN.setStyleSheet(common_stylesheet)
        self.typingbtn.setStyleSheet(common_stylesheet)
        self.keyboardbtn.setStyleSheet(common_stylesheet)


        self.mainlayout.addLayout(self.leftlayout, 0, 0, 4, 3)
        self.mainlayout.addWidget(self.seperator,0,3,4,1)
        self.mainlayout.addLayout(self.rightlayout, 0, 4, 4, 1)
        self.mainlayout.setHorizontalSpacing(20)

        self.setLayout(self.mainlayout)

    def TICTACTOE(self):
        self.clearLayout()
        self.TTTT = TTT.MainWindow()
        self.leftlayout.addWidget(self.TTTT)

    def STONE_PAPER_SCISSORS(self):
        self.clearLayout()
        self.SPS = Stone_papper_scissor.MainWindow()
        self.leftlayout.addWidget(self.SPS)

    def GuessNumber(self):
        self.clearLayout()
        self.GTNS = guess_the_number.MainWindow()
        self.leftlayout.addWidget(self.GTNS)

    def MathWidget(self):
        self.clearLayout()
        self.MATHS = maths_practice.MainWindow()
        self.leftlayout.addWidget(self.MATHS)

    def QuizWidget(self):
        self.clearLayout()
        self.QUIZZ = quiz.MainWindow()
        self.leftlayout.addWidget(self.QUIZZ)

    def Typing_game(self):
        self.clearLayout()
        self.typing = typing_test_game.Mainwindow()
        self.leftlayout.addWidget(self.typing)

    def keyboard_func(self):
        self.clearLayout()
        self.key = keyboard.MainWindow()
        self.leftlayout.addWidget(self.key)

    def clearLayout(self):
        while self.leftlayout.count():
            self.leftlayout.takeAt(0).widget().deleteLater()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()

    apply_stylesheet(app, 'dark_red.xml')

    window.show()
    sys.exit(app.exec())
    