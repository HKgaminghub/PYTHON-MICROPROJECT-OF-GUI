import sys
from PyQt6.QtCore import Qt
import PyQt6.QtWidgets as qtw
from PyQt6.QtWidgets import QApplication, QWidget
from qt_material import apply_stylesheet
import random as rand

class MainWindow(QWidget):
    
    def __init__(self):
        super().__init__()
        
        self.l1=[0,1,2,3,4,5,6,7,8,9]
        self.num=1
        self.qnum=10
        self.right=0
        self.wrong=0
        self.isstart=0
        self.total=0

        self.setStyleSheet("background-color : #000000")

        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, False)
        
        self.setWindowTitle("Quiz")
        self.setLayout(qtw.QVBoxLayout())
        self.keypad()


    def keypad(self):
        container=qtw.QWidget()
        container.setLayout(qtw.QGridLayout())

        self.btn_question=qtw.QPushButton("Question",self)
        self.btn_a=qtw.QPushButton("a",self)
        self.btn_b=qtw.QPushButton("b",self)
        self.btn_c=qtw.QPushButton("c",self)
        self.btn_d=qtw.QPushButton("d",self)
        self.btn_start=qtw.QPushButton("Start / Reset",self)
        self.btn_result=qtw.QPushButton("",self)
        self.btn_next=qtw.QPushButton("Next",self)

        common_stylesheet = """
            QPushButton {
                padding: 5px;
                background-color: #000000;
                color: #0EFF1E;
                border: 2px solid cyan;
                border-radius: 15px;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """

        self.btn_question.setStyleSheet(common_stylesheet)        
        self.btn_a.setStyleSheet(common_stylesheet)        
        self.btn_b.setStyleSheet(common_stylesheet)        
        self.btn_c.setStyleSheet(common_stylesheet)        
        self.btn_d.setStyleSheet(common_stylesheet)        
        self.btn_start.setStyleSheet(common_stylesheet)        
        self.btn_result.setStyleSheet(common_stylesheet)        
        self.btn_next.setStyleSheet(common_stylesheet)        

        container.layout().addWidget(self.btn_question,0,0,1,4)
        container.layout().addWidget(self.btn_a,1,0,1,1)
        container.layout().addWidget(self.btn_b,1,1,1,1)
        container.layout().addWidget(self.btn_c,1,2,1,1)
        container.layout().addWidget(self.btn_d,1,3,1,1)
        container.layout().addWidget(self.btn_result,2,0,1,4)
        container.layout().addWidget(self.btn_next,3,0,1,4)
        container.layout().addWidget(self.btn_start,4,0,1,4)
        
        
        self.btn_a.clicked.connect(self.func_a)
        self.btn_b.clicked.connect(self.func_b)
        self.btn_c.clicked.connect(self.func_c)
        self.btn_d.clicked.connect(self.func_d)
        self.btn_next.clicked.connect(self.next)
        self.btn_start.clicked.connect(self.func_start)

        self.layout().addWidget(container)

    def generator(self):
        self.num=rand.choice(self.l1)
        self.l1.remove(self.num) 
        
    
    def question(self):
        self.generator()
        if self.num==0:
            self.btn_question.setText("Who is the present PM of India ?")
            self.btn_a.setText("Giorgia Meloni")
            self.btn_b.setText("Narendra Modi")
            self.btn_c.setText("Amit Shah")
            self.btn_d.setText("Yogi")

        elif self.num==1:
            self.btn_question.setText("Who is the first president of india ?")
            self.btn_a.setText("Rajendra Prasad")
            self.btn_b.setText("Ram Nath Kovind")
            self.btn_c.setText("Abdul Kalam")
            self.btn_d.setText("Sardar Vallabhbhai Patel")

        elif self.num==2:
            self.btn_question.setText("Who is the first PM of India ?")
            self.btn_a.setText("Rahul Gandhi")
            self.btn_b.setText("Rajiv Gandhi")
            self.btn_c.setText("Jawaharlal Nehru")
            self.btn_d.setText("Atal Bihari Vajpayee")

        elif self.num==3:
            self.btn_question.setText("Who is the father of Shree Ramchandra ?")
            self.btn_a.setText("Vasudev")
            self.btn_b.setText("Dasharath")
            self.btn_c.setText("Shiv")
            self.btn_d.setText("Vishnu")

        elif self.num==4:
            self.btn_question.setText("Who is the father of Shree Krishna ?")
            self.btn_a.setText("Vasudev")
            self.btn_b.setText("Dasharath")
            self.btn_c.setText("Shiv")
            self.btn_d.setText("Vishnu")

        elif self.num==5:
            self.btn_question.setText("Who discovered zero (0) ?")
            self.btn_a.setText("Aryabhatta")
            self.btn_b.setText("Thomas Alva Edison")
            self.btn_c.setText("Maharshi Valmiki")
            self.btn_d.setText("Maharshi Vyas")

        elif self.num==6:
            self.btn_question.setText("Who is the present captian of cricket team india ?")
            self.btn_a.setText("M.S. Dhoni")
            self.btn_b.setText("Sachin Tandulkar")
            self.btn_c.setText("Virat Kohli")
            self.btn_d.setText("Rohit Sharma")

        elif self.num==7:
            self.btn_question.setText("Who Win the last ICC cup ?")
            self.btn_a.setText("India")
            self.btn_b.setText("Pakistan")
            self.btn_c.setText("Brazil")
            self.btn_d.setText("Australia")

        elif self.num==8:
            self.btn_question.setText("Who discover Gravity ?")
            self.btn_a.setText("Thomas Alva Edison")
            self.btn_b.setText("Isaac Newton")
            self.btn_c.setText("Albert Einstein")
            self.btn_d.setText("Galileo Galilei")

        else:
            self.btn_question.setText("Who invented Telescope  ?")
            self.btn_a.setText("Thomas Alva Edison")
            self.btn_b.setText("Isaac Newton")
            self.btn_c.setText("Albert Einstein")
            self.btn_d.setText("Galileo Galilei")

    def func_start(self):
        self.l1=[0,1,2,3,4,5,6,7,8,9]
        self.question()
        self.isstart=1

    def func_a(self):
        if self.isstart==1:

            if (self.num==1) or (self.num==4) or (self.num==5):
                self.btn_result.setText("Yes Your ans is Right. Press next")
                self.right+=1
                self.total=1
            elif self.num==20 :
                self.btn_question.setText("")
            else :
                self.btn_result.setText("Sorry your ans was wrong")
                self.total=1
                self.wrong+=1
                self.next()
        
        else :
            self.btn_result.setText("Please Start the game")
    
    def func_b(self):
        if self.isstart==1:

            if (self.num==0) or (self.num==3) or (self.num==8):
                self.btn_result.setText("Yes Your ans is Right. press next")
                self.right+=1
                self.total=1
            elif self.num==20 :
                self.btn_question.setText("")
            else :
                self.btn_result.setText("Sorry your ans was wrong")
                self.total=1
                self.wrong+=1
                self.next()

        else :
            self.btn_result.setText("Please Start the game")

    def func_c(self):
        if self.isstart==1:               
            if (self.num==2):
                self.btn_result.setText("Yes Your ans is Right. press next")
                self.right+=1
                self.total=1
            elif self.num==20 :
                self.btn_question.setText("")
            else :
                self.btn_result.setText("Sorry your ans was wrong")
                self.total=1
                self.wrong+=1

        else :
            self.btn_result.setText("Please Start the game")

    def func_d(self):
        if self.isstart==1:
            if (self.num==6) or (self.num==7) or (self.num==9):
                self.btn_result.setText("Yes Your ans is Right. press next")

                self.right+=1
                self.total=1
            elif self.num==20 :
                self.btn_question.setText("")
            else:
                self.btn_result.setText("Sorry your ans was wrong")
                self.total=1
                self.wrong+=1

                self.next()
        else :
            self.btn_result.setText("Please Start the game")

    def next(self):
        if self.total==1:
            if self.isstart==1:
                if self.l1==[]:
                    self.num=20
                    self.btn_result.setText(f"Your {self.right} are right and {self.wrong} are wrong")
                    self.btn_question.setText("")
                    self.btn_a.setText("")
                    self.btn_b.setText("")
                    self.btn_c.setText("")
                    self.btn_d.setText("")
                    
                else :
                    self.question()
                    self.btn_result.setText("")
            else:
                self.btn_result.setText("Please Start the game")
            self.total=0
        elif self.num==20:
            self.btn_question.setText("")
        else :
            self.btn_result.setText("Please Answer the quetion")

if __name__ == '__main__':
    app=QApplication(sys.argv)
    window=MainWindow()
    
    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    apply_stylesheet(app,'dark_red.xml')
    
    window.show()
    sys.exit(app.exec())