import sys
import threading
from PyQt6.QtCore import Qt, pyqtSignal
import PyQt6.QtWidgets as qtw
from PyQt6.QtWidgets import QApplication, QWidget
from PyQt6.QtGui import QIcon
from qt_material import apply_stylesheet
from playsound import playsound
import pyttsx3
import json
 
# Opening JSON file
keyMapJson = open('key_map.json')

threads = []

ConstantMusicPath = "C:/Users/hardb/OneDrive/Desktop/microproject/mUSIC/"

KeyFileJsonData = json.load(keyMapJson)

def getDynamicFilePath(keyCode):
    return ConstantMusicPath + KeyFileJsonData[keyCode.capitalize()]

class MainWindow(QWidget):

    SetTextSignal = pyqtSignal()
    
    def __init__(self):
        super().__init__()


        self.setFixedSize(625,350)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, False)
        self.setStyleSheet("background-color: #000000;")

        self.lower_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z','CAPS']

        self.upper_list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','caps']

        self.l1=[]
        self.result = ' '.join(map(str, self.l1))
        self.setWindowTitle("Keyboard")
        self.setLayout(qtw.QVBoxLayout())
        self.keypad()


    def keypad(self):
        container = qtw.QWidget(self)
        container.setLayout(qtw.QGridLayout())

        self.btn_result=qtw.QPushButton(f"{self.result}",self)
        self.btn_1=qtw.QPushButton("1",self)
        self.btn_2=qtw.QPushButton("2",self)
        self.btn_3=qtw.QPushButton("3",self)
        self.btn_4=qtw.QPushButton("4",self)
        self.btn_5=qtw.QPushButton("5",self)
        self.btn_6=qtw.QPushButton("6",self)
        self.btn_7=qtw.QPushButton("7",self)
        self.btn_8=qtw.QPushButton("8",self)
        self.btn_9=qtw.QPushButton("9",self)
        self.btn_0=qtw.QPushButton("0",self)
        self.btn_q=qtw.QPushButton("q",self)
        self.btn_w=qtw.QPushButton("w",self)
        self.btn_e=qtw.QPushButton("e",self)
        self.btn_r=qtw.QPushButton("r",self)
        self.btn_t=qtw.QPushButton("t",self)
        self.btn_y=qtw.QPushButton("y",self)
        self.btn_u=qtw.QPushButton("u",self)
        self.btn_i=qtw.QPushButton("i",self)
        self.btn_o=qtw.QPushButton("o",self)
        self.btn_p=qtw.QPushButton("p",self)
        self.btn_a=qtw.QPushButton("a",self)
        self.btn_s=qtw.QPushButton("s",self)
        self.btn_d=qtw.QPushButton("d",self)
        self.btn_f=qtw.QPushButton("f",self)
        self.btn_g=qtw.QPushButton("g",self)
        self.btn_h=qtw.QPushButton("h",self)
        self.btn_j=qtw.QPushButton("j",self)
        self.btn_k=qtw.QPushButton("k",self)
        self.btn_l=qtw.QPushButton("l",self)
        self.caps=qtw.QPushButton("CAPS",self)
        self.btn_z=qtw.QPushButton("z",self)
        self.btn_x=qtw.QPushButton("x",self)
        self.btn_c=qtw.QPushButton("c",self)
        self.btn_v=qtw.QPushButton("v",self)
        self.btn_b=qtw.QPushButton("b",self)
        self.btn_n=qtw.QPushButton("n",self)
        self.btn_m=qtw.QPushButton("m",self)
        self.btn_back=qtw.QPushButton(self)
        self.btn_back.setIcon(QIcon("backspace.png"))
        self.btn_123=qtw.QPushButton("📢",self)
        self.btn_coma=qtw.QPushButton(",",self)
        self.btn_space=qtw.QPushButton(" ",self)
        self.btn_and=qtw.QPushButton("?",self)
        self.btn_fulls=qtw.QPushButton(".",self)



        container.layout().addWidget(self.btn_result,0,0,1,20)
        container.layout().addWidget(self.btn_1,1,0,1,2)
        container.layout().addWidget(self.btn_2,1,2,1,2)
        container.layout().addWidget(self.btn_3,1,4,1,2)
        container.layout().addWidget(self.btn_4,1,6,1,2)
        container.layout().addWidget(self.btn_5,1,8,1,2)
        container.layout().addWidget(self.btn_6,1,10,1,2)
        container.layout().addWidget(self.btn_7,1,12,1,2)
        container.layout().addWidget(self.btn_8,1,14,1,2)
        container.layout().addWidget(self.btn_9,1,16,1,2)
        container.layout().addWidget(self.btn_0,1,18,1,2)
        container.layout().addWidget(self.btn_q,2,0,1,2)
        container.layout().addWidget(self.btn_w,2,2,1,2)
        container.layout().addWidget(self.btn_e,2,4,1,2)
        container.layout().addWidget(self.btn_r,2,6,1,2)
        container.layout().addWidget(self.btn_t,2,8,1,2)
        container.layout().addWidget(self.btn_y,2,10,1,2)
        container.layout().addWidget(self.btn_u,2,12,1,2)
        container.layout().addWidget(self.btn_i,2,14,1,2)
        container.layout().addWidget(self.btn_o,2,16,1,2)
        container.layout().addWidget(self.btn_p,2,18,1,2)
        container.layout().addWidget(self.btn_a,3,1,1,2)
        container.layout().addWidget(self.btn_s,3,3,1,2)
        container.layout().addWidget(self.btn_d,3,5,1,2)
        container.layout().addWidget(self.btn_f,3,7,1,2)
        container.layout().addWidget(self.btn_g,3,9,1,2)
        container.layout().addWidget(self.btn_h,3,11,1,2)
        container.layout().addWidget(self.btn_j,3,13,1,2)
        container.layout().addWidget(self.btn_k,3,15,1,2)
        container.layout().addWidget(self.btn_l,3,17,1,2)
        container.layout().addWidget(self.caps,4,0,1,3)
        container.layout().addWidget(self.btn_z,4,3,1,2)
        container.layout().addWidget(self.btn_x,4,5,1,2)
        container.layout().addWidget(self.btn_c,4,7,1,2)
        container.layout().addWidget(self.btn_v,4,9,1,2)
        container.layout().addWidget(self.btn_b,4,11,1,2)
        container.layout().addWidget(self.btn_n,4,13,1,2)
        container.layout().addWidget(self.btn_m,4,15,1,2)
        container.layout().addWidget(self.btn_back,4,17,1,3)
        container.layout().addWidget(self.btn_123,5,0,1,3)
        container.layout().addWidget(self.btn_coma,5,3,1,2)
        container.layout().addWidget(self.btn_space,5,5,1,10)
        container.layout().addWidget(self.btn_and,5,15,1,2)
        container.layout().addWidget(self.btn_fulls,5,17,1,3)

        common_stylesheet = """
            QPushButton {
                padding: 2px;
                background-color: #000000;
                text-transform: none;
                color: #0EFF1E;
                border: 2px solid cyan;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """
        uncommon_stylesheet = """
            QPushButton {
                padding: 2px;
                background-color: #000000;
                text-transform: none;
                color: #E00B78;
                border: 2px solid #E00B78;
                
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #E00B78;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #E00B78;           
            """
        uuncommon_stylesheet = """
            QPushButton {
                padding: 2px;
                background-color: #000000;
                text-transform: none;
                color:  #E00B78;
                border: 2px solid #E00B78;
                font-family: 'YourDesiredFont', sans-serif;
            }          
            """
        self.uncommon_set_button_list = [self.btn_123,self.caps,self.btn_space,self.btn_and,self.btn_fulls,self.btn_back,self.btn_coma,self.btn_result]
        self.common_set_button_list = [self.btn_a, self.btn_b, self.btn_c, self.btn_d, self.btn_e, self.btn_f, self.btn_g, self.btn_h, self.btn_i, self.btn_j,self.btn_k, self.btn_l, self.btn_m, self.btn_n, self.btn_o, self.btn_p, self.btn_q, self.btn_r, self.btn_s, self.btn_t,self.btn_u, self.btn_v, self.btn_w, self.btn_x, self.btn_y, self.btn_z,self.btn_0,self.btn_1,self.btn_2,self.btn_3,self.btn_4,self.btn_5,self.btn_6,self.btn_7,self.btn_8,self.btn_9]
        # self.text =  [self.btn_a.text(), self.btn_b.text(), self.btn_c.text(), self.btn_d.text(), self.btn_e.text(), self.btn_f.text(), self.btn_g.text(), self.btn_h.text(), self.btn_i.text(), self.btn_j.text(),self.btn_k.text(), self.btn_l.text(), self.btn_m.text(), self.btn_n.text(), self.btn_o.text(), self.btn_p.text(), self.btn_q.text(), self.btn_r.text(), self.btn_s.text(), self.btn_t.text(),self.btn_u.text(), self.btn_v.text(), self.btn_w.text(), self.btn_x.text(), self.btn_y.text(), self.btn_z.text(),self.btn_0.text(),self.btn_1.text(),self.btn_2.text(),self.btn_3.text(),self.btn_4.text(),self.btn_5.text(),self.btn_6.text(),self.btn_7.text(),self.btn_8.text(),self.btn_9.text()]
        # for button in self.common_set_button_list:
        #     button.clicked.connect(self.func_a_thread(button.text()))
        self.btn_a.clicked.connect(lambda: self.func_a_thread(self.btn_a.text()))
        self.btn_b.clicked.connect(lambda: self.func_a_thread(self.btn_b.text()))
        self.btn_c.clicked.connect(lambda: self.func_a_thread(self.btn_c.text()))
        self.btn_d.clicked.connect(lambda: self.func_a_thread(self.btn_d.text()))
        self.btn_e.clicked.connect(lambda: self.func_a_thread(self.btn_e.text()))
        self.btn_f.clicked.connect(lambda: self.func_a_thread(self.btn_f.text()))
        self.btn_g.clicked.connect(lambda: self.func_a_thread(self.btn_g.text()))
        self.btn_h.clicked.connect(lambda: self.func_a_thread(self.btn_h.text()))
        self.btn_i.clicked.connect(lambda: self.func_a_thread(self.btn_i.text()))
        self.btn_j.clicked.connect(lambda: self.func_a_thread(self.btn_j.text()))
        self.btn_k.clicked.connect(lambda: self.func_a_thread(self.btn_k.text()))
        self.btn_l.clicked.connect(lambda: self.func_a_thread(self.btn_l.text()))
        self.btn_m.clicked.connect(lambda: self.func_a_thread(self.btn_m.text()))
        self.btn_n.clicked.connect(lambda: self.func_a_thread(self.btn_n.text()))
        self.btn_o.clicked.connect(lambda: self.func_a_thread(self.btn_o.text()))
        self.btn_p.clicked.connect(lambda: self.func_a_thread(self.btn_p.text()))
        self.btn_q.clicked.connect(lambda: self.func_a_thread(self.btn_q.text()))
        self.btn_r.clicked.connect(lambda: self.func_a_thread(self.btn_r.text()))
        self.btn_s.clicked.connect(lambda: self.func_a_thread(self.btn_s.text()))
        self.btn_t.clicked.connect(lambda: self.func_a_thread(self.btn_t.text()))
        self.btn_u.clicked.connect(lambda: self.func_a_thread(self.btn_u.text()))
        self.btn_v.clicked.connect(lambda: self.func_a_thread(self.btn_v.text()))
        self.btn_w.clicked.connect(lambda: self.func_a_thread(self.btn_w.text()))
        self.btn_x.clicked.connect(lambda: self.func_a_thread(self.btn_x.text()))
        self.btn_y.clicked.connect(lambda: self.func_a_thread(self.btn_y.text()))
        self.btn_z.clicked.connect(lambda: self.func_a_thread(self.btn_z.text()))
        self.btn_1.clicked.connect(lambda: self.func_a_thread(self.btn_1.text()))
        self.btn_2.clicked.connect(lambda: self.func_a_thread(self.btn_2.text()))
        self.btn_3.clicked.connect(lambda: self.func_a_thread(self.btn_3.text()))
        self.btn_4.clicked.connect(lambda: self.func_a_thread(self.btn_4.text()))
        self.btn_5.clicked.connect(lambda: self.func_a_thread(self.btn_5.text()))
        self.btn_6.clicked.connect(lambda: self.func_a_thread(self.btn_6.text()))
        self.btn_7.clicked.connect(lambda: self.func_a_thread(self.btn_7.text()))
        self.btn_8.clicked.connect(lambda: self.func_a_thread(self.btn_8.text()))
        self.btn_9.clicked.connect(lambda: self.func_a_thread(self.btn_9.text()))
        self.btn_0.clicked.connect(lambda: self.func_a_thread(self.btn_0.text()))
        self.caps.clicked.connect(lambda: self.func_caps())
        self.btn_123.clicked.connect(lambda: self.speak())
        self.btn_coma.clicked.connect(lambda: self.extra(self.btn_coma))
        self.btn_space.clicked.connect(lambda: self.extra(self.btn_space))
        self.btn_and.clicked.connect(lambda: self.extra(self.btn_and))
        self.btn_fulls.clicked.connect(lambda: self.extra(self.btn_fulls))
        self.btn_back.clicked.connect(lambda: self.func_back())
    
        for button in self.common_set_button_list:
            button.setStyleSheet(common_stylesheet)
        for button in self.uncommon_set_button_list:
            button.setStyleSheet(uncommon_stylesheet)





        self.layout().addWidget(container)
        self.button_list = [self.btn_a, self.btn_b, self.btn_c, self.btn_d, self.btn_e, self.btn_f, self.btn_g, self.btn_h, self.btn_i, self.btn_j,self.btn_k, self.btn_l, self.btn_m, self.btn_n, self.btn_o, self.btn_p, self.btn_q, self.btn_r, self.btn_s, self.btn_t,self.btn_u, self.btn_v, self.btn_w, self.btn_x, self.btn_y, self.btn_z,self.caps]


    def func_a_thread(self,buttonText):
        t = threading.Thread(target=self.func_a,args=buttonText)
        t.start()
        threads.append(t)
        
    def func_a(self,hi):
        self.l1.append(hi)
        result = ''.join(map(str, self.l1))
        self.btn_result.setText(result)
        playsound(getDynamicFilePath(hi))
        
    def func_caps(self):
        if self.caps.text()=="caps":
            for button, new_text in zip(self.button_list, self.lower_list):
                button.setText(new_text)
        else :
            for button, new_text in zip(self.button_list, self.upper_list):
                button.setText(new_text)

    def extra(self,button):
        i = button.text()
        self.l1.append(i)
        result = ''.join(map(str, self.l1))
        self.btn_result.setText(result)

    def speak(self):
        result = ''.join(map(str, self.l1))
        pyttsx3.speak(result)

    def func_back(self):
        if self.l1!=[]:
            self.l1.pop()
            result = ''.join(map(str, self.l1))
            self.btn_result.setText(result)

if __name__ == '__main__':
    app=QApplication(sys.argv)
    window=MainWindow()
    
    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    apply_stylesheet(app, 'dark_pink.xml')
    
    window.show()
    sys.exit(app.exec())