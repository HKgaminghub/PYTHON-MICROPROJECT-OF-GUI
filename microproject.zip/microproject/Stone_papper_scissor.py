import sys
from PyQt6.QtCore import Qt
import PyQt6.QtWidgets as qtw
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QWidget, QFrame, QGridLayout, QVBoxLayout, QPushButton
from qt_material import apply_stylesheet
import random

isdone=0
computer_scr=0
computer_rand=0
player_scr=0
player_cho=""
computer_cho=""
class MainWindow(QWidget):
 
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Stone Papper Sicssor")
        self.setLayout(qtw.QVBoxLayout())

        self.keypad()

    def keypad(self):
        global player_scr,computer_scr
        container = qtw.QWidget(self)
        container.setLayout(qtw.QGridLayout())

        self.setWindowTitle("Stone Paper Sicssor")

        self.btn_stone=qtw.QPushButton("🪨 Rock",self)
        self.btn_papper=qtw.QPushButton("📄 Papper",self)
        self.btn_sicssor=qtw.QPushButton("✂️ Sicssor",self)
        self.result_lable=qtw.QPushButton("",self)
        self.btn_player=qtw.QPushButton("Player",self)
        self.btn_computer=qtw.QPushButton("Computer",self)
        self.scr_player=qtw.QPushButton(f"{player_scr}",self)
        self.scr_computer=qtw.QPushButton(f"{computer_scr}",self)

        container.layout().addWidget(self.btn_stone,0,0,2,2)
        container.layout().addWidget(self.btn_papper,0,2,2,2)
        container.layout().addWidget(self.btn_sicssor,0,4,2,2)
        container.layout().addWidget(self.result_lable,4,0,2,6)
        container.layout().addWidget(self.btn_player,6,0,2,3)
        container.layout().addWidget(self.btn_computer,6,3,2,3)
        container.layout().addWidget(self.scr_player,8,0,2,3)
        container.layout().addWidget(self.scr_computer,8,3,2,3)

        common_stylesheet = """
            QPushButton {
                padding: 5px;
                background-color: #000000;
                color: #0EFF1E;
                border: 2px solid cyan;
                border-radius: 15px;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """
        self.btn_stone.setStyleSheet(common_stylesheet)
        self.btn_papper.setStyleSheet(common_stylesheet)
        self.btn_sicssor.setStyleSheet(common_stylesheet)
        self.result_lable.setStyleSheet(common_stylesheet)
        self.btn_player.setStyleSheet(common_stylesheet)
        self.btn_computer.setStyleSheet(common_stylesheet)
        self.scr_player.setStyleSheet(common_stylesheet)
        self.scr_computer.setStyleSheet(common_stylesheet)


        self.btn_stone.clicked.connect(lambda: self.func_stone())
        self.btn_papper.clicked.connect(lambda: self.func_papper())
        self.btn_sicssor.clicked.connect(lambda: self.func_sicssor())
        self.layout().addWidget(container)


    def func_stone(self):
        global player_cho,isdone,player_n
        player_cho="stone"
        player_n=0
        isdone=1
        self.func_submit()

    def func_papper(self):
        global player_cho,isdone,player_n
        player_n=1
        player_cho="papper"
        isdone=1
        self.func_submit()

    def func_sicssor(self):
        global player_cho,isdone,player_n
        player_n=2
        player_cho="sicssor"
        isdone=1
        self.func_submit()


    def func_random(self):
        return random.randint(0,2)

    def func_submit(self):
        global computer_scr,player_scr,player_cho,computer_cho,isdone
        computer_rand=self.func_random()

        if computer_rand==0:
            computer_cho="stone"
        elif computer_rand==1:
            computer_cho="papper"
        else:
            computer_cho="sicssor"

        if isdone!=0:
            if player_n==computer_rand:
                self.result_lable.setText(f"Match Draw you and computer both choose {player_cho}")
            elif (player_n==0 and computer_rand==1) or (player_n==1 and computer_rand==2) or (player_n==2 and computer_rand==0):
                self.result_lable.setText(f"Computer win the match. You choose {player_cho} and computer choose {computer_cho}") 
                computer_scr+=1   
                self.scr_computer.setText(f"{computer_scr}")
            else :
                self.result_lable.setText(f"You win the match. You choose {player_cho} and computer choose {computer_cho}")
                player_scr+=1
                self.scr_player.setText(f"{player_scr}")
            isdone=0
        else:
            self.result_lable.setText("Pls choose something!")




if __name__ == '__main__':
    app=QApplication(sys.argv)
    window=MainWindow()
    
    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    
    window.show()
    sys.exit(app.exec())