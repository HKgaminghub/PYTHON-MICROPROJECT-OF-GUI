import sys
from PyQt6.QtCore import Qt
import PyQt6.QtWidgets as qtw
from PyQt6.QtWidgets import QApplication, QWidget
from qt_material import apply_stylesheet

player1=0
player2=0
player=1
iswin=0
box=0


class MainWindow(QWidget):
    
    def __init__(self):
        super().__init__()
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, False)
        self.setStyleSheet("background-color: #000000;")
        
        self.setWindowTitle("TIC TAC TOE")
        self.setLayout(qtw.QVBoxLayout())
        self.keypad()

    def keypad(self):
        global player1,player2
        container = qtw.QWidget(self)
        container.setLayout(qtw.QGridLayout())

        self.player1b=qtw.QPushButton("player1",self)
        self.player2b=qtw.QPushButton("player2",self)
        self.player1s=qtw.QPushButton(f"{player1}",self)
        self.player2s=qtw.QPushButton(f"{player2}",self)
        self.bt00=qtw.QPushButton('',self)
        self.bt01=qtw.QPushButton('',self)
        self.bt02=qtw.QPushButton('',self)
        self.bt10=qtw.QPushButton('',self)
        self.bt11=qtw.QPushButton('',self)
        self.bt12=qtw.QPushButton('',self)
        self.bt20=qtw.QPushButton('',self)
        self.bt21=qtw.QPushButton('',self)
        self.bt22=qtw.QPushButton('',self)
        self.result=qtw.QPushButton('',self)
        self.reset=qtw.QPushButton('Reset',self)


        common_stylesheet = """
            QPushButton {
                padding: 15px;
                background-color: #000000;
                color: #0EFF1E;
                border: 2px solid cyan;
                border-radius: 15px;
            }
            QPushButton:hover {
                background-color: #333;
                border-color: #045A85;
            }
            QPushButton:pressed {
                background-color: #555;
                border-color: #033594;
            }
            """
        self.button_list = [self.player1b,self.player2b,self.player1s,self.player2s,self.bt00,self.bt01,self.bt02,self.bt10,self.bt11,self.bt12,self.bt20,self.bt21,self.bt22,self.result,self.reset]
        for button in self.button_list:
            button.setStyleSheet(common_stylesheet)

        container.layout().addWidget(self.bt00, 0, 0,2,2)
        container.layout().addWidget(self.bt01, 0, 2,2,2)
        container.layout().addWidget(self.bt02, 0, 4,2,2)
        container.layout().addWidget(self.bt10, 2, 0,2,2)
        container.layout().addWidget(self.bt11, 2, 2,2,2)
        container.layout().addWidget(self.bt12, 2, 4,2,2)
        container.layout().addWidget(self.bt20, 4, 0,2,2)
        container.layout().addWidget(self.bt21, 4, 2,2,2)
        container.layout().addWidget(self.bt22, 4, 4,2,2)
        container.layout().addWidget(self.result,6,0,1,6)
        container.layout().addWidget(self.reset,9,0,1,6)
        container.layout().addWidget(self.player1b,12,0,1,3)
        container.layout().addWidget(self.player2b,12,3,1,3)
        container.layout().addWidget(self.player1s,13,0,1,3)
        container.layout().addWidget(self.player2s,13,3,1,3)

        self.bt00.clicked.connect(lambda: self.on_button_click(self.bt00))
        self.bt01.clicked.connect(lambda: self.on_button_click(self.bt01))
        self.bt02.clicked.connect(lambda: self.on_button_click(self.bt02))
        self.bt10.clicked.connect(lambda: self.on_button_click(self.bt10))
        self.bt11.clicked.connect(lambda: self.on_button_click(self.bt11))
        self.bt12.clicked.connect(lambda: self.on_button_click(self.bt12))
        self.bt20.clicked.connect(lambda: self.on_button_click(self.bt20))
        self.bt21.clicked.connect(lambda: self.on_button_click(self.bt21))
        self.bt22.clicked.connect(lambda: self.on_button_click(self.bt22))
        self.reset.clicked.connect(lambda: self.resets(self.bt00,self.bt01,self.bt02,self.bt10,self.bt11,self.bt12,self.bt20,self.bt21,self.bt22,self.result))
        self.layout().addWidget(container)
    

    def resets(self,b1,b2,b3,b4,b5,b6,b7,b8,b9,re):
        global iswin,player,box
        player=1
        b1.setText('')
        b2.setText('')
        b3.setText('')
        b4.setText('')
        b5.setText('')
        b6.setText('')
        b7.setText('')
        b8.setText('')
        b9.setText('')
        re.setText('')
        iswin=0
        box=0


    def on_button_click(self,button): 
        global player
        global box,iswin
        if iswin==0:
            if button.text()=='' :
                if player==1:
                    button.setText("X")
                    player=2
                    box+=1
                elif player==2:
                    button.setText("O")
                    player=1
                    box+=1
                self.check_win(self.bt00,self.bt01,self.bt02,self.bt10,self.bt11,self.bt12,self.bt20,self.bt21,self.bt22,self.result,self.player1s,self.player2s)
    def check_win(self,b1,b2,b3,b4,b5,b6,b7,b8,b9,re,p1,p2):
        global player,iswin,player1,player2
        if b1.text()==b2.text()==b3.text() and b1.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1
            if player==1:
                player1+=1
            else :
                player2+=1
        elif b4.text()==b5.text()==b6.text()  and b4.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1
            if player==1:
                player1+=1
            else :
                player2+=1
        elif b7.text()==b8.text()==b9.text() and b7.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1
            if player==1:
                player1+=1
            else :
                player2+=1
        elif b1.text()==b5.text()==b9.text() and b1.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1
            if player==1:
                player1+=1
            else :
                player2+=1
        elif b3.text()==b5.text()==b7.text() and b3.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1
            if player==1:
                player1+=1
            else :
                player2+=1
        elif b1.text()==b4.text()==b7.text() and b1.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1
            if player==1:
                player1+=1
            else :
                player2+=1
        elif b2.text()==b5.text()==b8.text() and b2.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1
            if player==1:
                player1+=1
            else :
                player2+=1
        elif b3.text()==b6.text()==b9.text() and b3.text()!='':
            player=3-player
            re.setText(f"player {player} win!")
            iswin=1       
            if player==1:
                player1+=1
            else :
                player2+=1     
        elif box == 9:
          re.setText("Draw!")

        p1.setText(f"{player1}")
        p2.setText(f"{player2}")

 
 
 
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window=MainWindow()
    
    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    
    window.show()
    sys.exit(app.exec())
    